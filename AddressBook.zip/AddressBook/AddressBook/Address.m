//
//  Address.m
//  AddressBookCoreData
//
//  Created by alexchoi1 on 8/7/13.
//  Copyright (c) 2013 Good Time Games. All rights reserved.
//

#import "Address.h"
#import "Person.h"


@implementation Address

@dynamic streetAddress;
@dynamic addressType;
@dynamic persons;

@end
