//
//  Person.m
//  AddressBookCoreData
//
//  Created by alexchoi1 on 8/7/13.
//  Copyright (c) 2013 Good Time Games. All rights reserved.
//

#import "Person.h"
#import "Address.h"


@implementation Person

@dynamic firstName;
@dynamic lastName;
@dynamic phoneNumber;
@dynamic emailAddress;
@dynamic addresses;

@end
